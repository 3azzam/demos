import React , {Component} from 'react' ;
import './news.css'


class NewsBlock extends Component{

  render(){
    return(
      <section id="content">

      <div className = "wrapper" >

                <div className = "block" >
                <div className = "firstItem" >
                    <h2> template wow </h2>
                    <p>
                         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                    </p>
                    <div  >
                        <a href="#" > donwload pdf </a>
                    </div>
                </div>

                <div className ="secondItem" >
                    <img src ="city.png" />
                </div>
                </div>

                <div className = "block" >
                <div className = "firstItem" >
                    <h2> template wow </h2>
                    <p>
                         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                    </p>
                    <div  >
                        <a href="#" > donwload pdf </a>
                    </div>
                </div>

                <div className ="secondItem" >
                    <img src ="city.png" />
                </div>
                </div>


                <div className = "block" >
                <div className = "firstItem" >
                    <h2> template wow </h2>
                    <p>
                         Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                    </p>
                    <div  >
                        <a href="#" > donwload pdf </a>
                    </div>
                </div>

                <div className ="secondItem" >
                    <img src ="city.png" />
                </div>
                </div>

        </div>

      <div className ="viewMorebtn" >
            <button type="button" class="btn">view More</button>
        </div>

      </section>

    )
  }
}

export default NewsBlock ;
