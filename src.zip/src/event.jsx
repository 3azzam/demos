import React , {Component} from 'react' ;
import './event.css'


class EventBlock extends Component {

  render(){
    return(
        <section id="content">

              <div className = "wrapper" >



              <div class = "block" >
                <div class = "firstItem" >
                    <h> <small>this is date</small> </h>
                    <h2> template wow </h2>
                    <div class="dash">
                        <font color="red" size="20px">-</font>
                        <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                        </p>
                    </div>
                </div>
              </div>


              <div class = "block" >
                <div class = "firstItem" >
                    <h> <small>this is date</small> </h>
                    <h2> template wow </h2>
                    <div class="dash">
                        <font color="red" size="20px">-</font>
                        <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                        </p>
                    </div>
                </div>
              </div>


              <div class = "block" >
                <div class = "firstItem" >
                    <h> <small>this is date</small> </h>
                    <h2> template wow </h2>
                    <div class="dash">
                        <font color="red" size="20px">-</font>
                        <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla quo eveniet placeat. In porro, repudiandae ipsum voluptatibus ratione enim accusantium rem consequatur ab? Alias tenetur ratione quibusdam accusantium aut quis totam! Voluptas labore officiis, unde sequi ad fuga, ex assumenda dolorem placeat atque excepturi ipsa architecto dolores dignissimos quod quibusdam quasi repellat vero cum perspiciatis laboriosam qui sint exercitationem quisquam. Quisquam suscipit fugiat doloremque quasi ad debitis dolor quaerat nihil aliquam at ducimus consequuntur repudiandae numquam eligendi, fugit, excepturi doloribus!
                        </p>
                    </div>
                </div>
              </div>

        </div>

        <div class="viewMorebtn">
           <button type="button" class="btn">view More</button>
       </div>


        </section>
    )
  }

}

export default EventBlock;
