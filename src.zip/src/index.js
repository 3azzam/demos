import React from 'react' ;
import ReactDom from 'react-dom' ;
import  NewsBlock from './news'
import EventBlock from './event'

ReactDom.render(
  <EventBlock/> , document.getElementById('root')
)
