package com.example.android.metroapp;

public class Station {

    private int id ;
    private String name ;
    private int state ;
    private int lineNumber ;


    public Station()
    {
        id = 0 ;
        name = "" ;
        state = 0 ;
        lineNumber = 0 ;
    }

    public Station(String name , int id , int state , int lineNumber)
    {
        this.name = name ;
        this.id = id ;
        this.state = state ;
        this.lineNumber = lineNumber ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }
}
