package com.example.android.metroapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class LinesListActivity extends AppCompatActivity implements View.OnClickListener {

    private Button one ;
    private Button two ;
    private Button three ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lines_list);

        one = (Button) findViewById(R.id.one) ;
        two = (Button) findViewById(R.id.two) ;
        three = (Button) findViewById(R.id.three) ;

        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        Intent i = new Intent(this , ShowLines.class) ;

        if(view.getId() == R.id.one)
        {
            i.putExtra("line" , 1) ;
        }
        else if(view.getId() == R.id.two)
        {
            i.putExtra("line" , 2) ;
        }
        else
            i.putExtra("line" , 3) ;

        startActivity(i);
    }
}
