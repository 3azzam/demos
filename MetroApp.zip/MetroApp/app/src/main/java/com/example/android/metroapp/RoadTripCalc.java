package com.example.android.metroapp;

import com.example.android.metroapp.DataBase.DbModel;

import java.util.ArrayList;
import java.util.Collections;

public class RoadTripCalc {

    public ArrayList<Station> first ;
    public ArrayList<Station> second ;
    public ArrayList<Station> third ;


    private int idx ;  // var to store result from transition station

    public RoadTripCalc()
    {

    }

    public RoadTripCalc(DbModel dbModel )
    {
        first = dbModel.getFirstLine() ;
        second = dbModel.getSecondLine() ;
        third = dbModel.getThirdLine() ;
        setTransition();
        setIds();
    }


    public ArrayList<Station> start(String a , String b)
    {
        Station begin = getStation(a) ;
        Station end = getStation(b) ;

        ArrayList<Station> temp ;
        if( begin.getLineNumber() == end.getLineNumber() )
        {
            temp = transitionIsEqual(begin, end) ;
            //temp.add(end) ;
            return temp ;
        }
        else
        {
            if(begin.getLineNumber() > end.getLineNumber())
            {
                temp = myRoad(end, begin) ;
                Collections.reverse(temp);
            }
            else temp = myRoad(begin, end) ;
            return temp ;
        }
    }

    public void setTransition()
    {
        for(int i = 0 ; i < first.size() ; i++)
        {
            if(first.get(i).getName().equals("السادات"))
                first.get(i).setState(2);

            if(first.get(i).getName().equals("الشهداء"))
                first.get(i).setState(2);
        }

        for(int i = 0 ; i < second.size() ; i++)
        {
            if( second.get(i).getName().equals("السادات") )
                second.get(i).setState(1);

            if( second.get(i).getName().equals("الشهداء") )
                second.get(i).setState(1);

            if( second.get(i).getName().equals("العتبة") )
                second.get(i).setState(3);
        }

        for(int i = 0 ; i < third.size() ; i++)
        {
            if(third.get(i).getName().equals("العتبة"))
                third.get(i).setState(2) ;
        }

    }

    public void setIds()
    {
        for(int i = 0 ; i < first.size() ; i++)
            first.get(i).setId(i+1);

        for(int i = 0 ; i < second.size() ; i++)
            second.get(i).setId(i+1);

        for(int i = 0 ; i < third.size() ; i++)
            third.get(i).setId(i+1);

    }

    public Station getStation(String name)
    {
        for(int i = 0 ; i < first.size() ; i++)
            if(first.get(i).getName().equals(name)) return first.get(i) ;

        for(int i = 0 ; i < second.size() ; i++)
            if(second.get(i).getName().equals(name)) return second.get(i) ;

        for(int i = 0 ; i < third.size() ; i++)
            if(third.get(i).getName().equals(name)) return third.get(i) ;

        return null ;
    }

    public ArrayList<Station> myRoad(Station begin , Station end)
    {
        ArrayList<Station> arr = new ArrayList<>() ;

        Station st = begin ;
        for(int i = begin.getLineNumber() ; i < end.getLineNumber() ; i++ )
        {
            ArrayList<Station> temp = transitionsNotTheSame(st , i+1 ) ;

            arr.addAll(temp) ;

            if(i+1 == 1) st = first.get(idx) ;
            else if ( i+1 == 2)
            {
                st = first.get(idx) ;
                for(int j = 0 ; j < second.size() ; j++)
                    if(second.get(j).getName().equals( st.getName() ) ) st = second.get(j) ;
            }
            else //st = third.get(idx) ;
            {
                st = second.get(idx) ;
                for(int j = 0 ; j < third.size() ; j++)
                    if(third.get(j).getName().equals(st.getName())) st = third.get(j) ;
            }
        }

        arr.addAll( transitionIsEqual(st, end) ) ;

        return arr ;
    }

    public ArrayList<Station> transitionIsEqual(Station begin , Station end)
    {
        ArrayList<Station> ans= new ArrayList<>() ;
        for(int i = (int) Min( begin.getId() , end.getId()) ; i < (int) Max(begin.getId() , end.getId()) ; i++ )
        {
            if( begin.getLineNumber() == 1 ) ans.add(first.get(i)) ;
            else if(begin.getLineNumber() ==2) ans.add(second.get(i)) ;
            else ans.add(third.get(i)) ;
        }
        if( ans.get(0).getName().equals(begin.getName()) ) Collections.reverse(ans);
        return ans ;

    }

    public ArrayList<Station> transitionsNotTheSame(Station st , int secondLine)
    {
        boolean flag = true ;
        idx = 0 ;
        ArrayList<Station> stations = new ArrayList<>() ;

        if(st.getLineNumber() == 1)
        {
            for(int i = 0 ; i < first.size() ; i++ )
            {
                if( first.get(i).getState() != 0 && first.get(i).getState() == secondLine && first.get(i).getName() != st.getName() )
                {
                    idx = i ;
                    if(idx > st.getId() )
                        break;
                }
            }
            for(int i = (int) Min( first.get(idx).getId() , st.getId() )  ; i <= (int) Max( first.get(idx).getId() , st.getId() ) ; i++ )
                stations.add( first.get(i) ) ;

            if(stations.get(0).getName().equals(st.getName()) == false ) Collections.reverse(stations);
            return stations ;

        }
        else if( st.getLineNumber() == 2 )
        {
            for(int i = 0 ; i < second.size() ; i++ )
            {
                if( second.get(i).getState() != 0 && second.get(i).getState() == secondLine && second.get(i).getName() != st.getName() )
                {
                    idx = i ;
                    if(idx > st.getId() )
                        break;
                }
            }
            for(int i = (int) Min( second.get(idx).getId() , st.getId() )  ; i < (int) Max( second.get(idx).getId() , st.getId() ) ; i++ )
                stations.add( second.get(i) ) ;

            if(stations.get(0).getName().equals(st.getName()) == false ) Collections.reverse(stations);
            return stations ;
        }
        else if( st.getLineNumber() == 3 )
        {
            for(int i = 0 ; i < third.size() ; i++ )
            {
                if(third.get(i).getState() != 0 && third.get(i).getState() == secondLine && second.get(i).getName() != st.getName() )
                {
                    idx = i ;
                    if(idx > st.getId())
                        break;
                }
            }
            for(int i = Min(third.get(idx).getId() , st.getId() ) ; i < Max( third.get(idx).getId() , st.getId() ) ; i++)
                stations.add( third.get(i) ) ;

            if(stations.get(0).getName().equals(st.getName()) == false ) Collections.reverse(stations);
            return stations ;
        }

        else return null ;
    }

    public int Min(int a , int b)
    {
        if(a < b) return  a;
        else return b ;
    }

    public int Max(int a , int b)
    {
        if(a > b) return  a ;
        else return  b ;
    }

}
