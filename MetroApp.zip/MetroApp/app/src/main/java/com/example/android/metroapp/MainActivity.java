package com.example.android.metroapp;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.android.metroapp.DataBase.DbModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText from ;
    private EditText to;
    private Button go ;
    private Button lines ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        from = (EditText) findViewById(R.id.from) ;
        to = (EditText) findViewById(R.id.to) ;

        go = (Button) findViewById(R.id.go) ;
        go.setOnClickListener(this);

        lines = (Button) findViewById(R.id.lines) ;
        lines.setOnClickListener(this);

         //CreateDataBase();
    }

    public void  CreateDataBase()
    {
        DbModel dbModel = new DbModel(this)  ;

        ArrayList<Station> firstLine = new ArrayList<>() ;
        ArrayList<Station> secondLine = new ArrayList<>() ;
        ArrayList<Station> thirdLine = new ArrayList<>() ;

        // create Three Lines to add to database
        firstLine = makeStation( initFirstLine() , 1 ) ;
        secondLine = makeStation( initSecondLine() , 2 ) ;
        thirdLine = makeStation( initThirdLine() , 3) ;

        for(int i = 0 ; i < firstLine.size() ; i++ )
            dbModel.addStationToFirstLine(firstLine.get(i));

        for(int i = 0 ; i < secondLine.size() ; i++)
        dbModel.addStationToSecondLine(secondLine.get(i));

        for(int i= 0 ; i < thirdLine.size() ; i++)
            dbModel.addStationToThirdLine(thirdLine.get(i));
    }


    public ArrayList<String> initFirstLine()
    {
        ArrayList<String> firstLine = new ArrayList<>() ;
        firstLine.add("حلوان") ;
        firstLine.add("عين حلوان") ;
        firstLine.add("جامعة حلوان") ;
        firstLine.add("وادى حوف") ;
        firstLine.add("حدائق حلوان") ;
        firstLine.add("المعصرة") ;
        firstLine.add("طرة الاسمنت") ;
        firstLine.add("كوتسيكا") ;
        //firstLine.add("") ;
        firstLine.add("طرة البلد") ;
        firstLine.add("ثكنات المعادى") ;
        firstLine.add("المعادى") ;
        firstLine.add("حدائق المعادى") ;
        firstLine.add("دار السلام") ;
        firstLine.add("الزهراء") ;
        firstLine.add("مار جرجس") ;
        firstLine.add("الملك الصالح") ;
        firstLine.add("السيدة زينب") ;
        firstLine.add("سعد زعلول") ;
        firstLine.add("السادات") ;   /* transition station 1,2 */
        firstLine.add("ناصر") ;
        firstLine.add("عرابى") ;
        firstLine.add("الشهداء") ; /* transition station 1,2 */
        firstLine.add("غمرة") ;
        firstLine.add("الدمرداش") ;
        firstLine.add("منشية الصدر") ;
        firstLine.add("كوبرى القبة") ;
        firstLine.add("حمامات القبة") ;
        firstLine.add("سراى القبة") ;
        firstLine.add("حدائق الزيتون") ;
        firstLine.add("حلمية الزيتون") ;
        firstLine.add("المطرية") ;
        firstLine.add("عين شمس") ;
        firstLine.add("عزبة النخل") ;
        firstLine.add("المرج") ;
        firstLine.add("المرج الجديدة") ;

        return firstLine ;
    }

    public ArrayList<String> initSecondLine()
    {
        ArrayList<String> secondLine = new ArrayList() ;
        secondLine.add("المنيب");
        secondLine.add("ساقية مكى ");
        secondLine.add("أم المصريين");
        secondLine.add("الجيزة");
        secondLine.add("فيصل");
        secondLine.add("جامعة القاهرة");
        secondLine.add("البحوث");
        secondLine.add("الدقى");
        secondLine.add("الأوبرا");
        secondLine.add("السادات");
        secondLine.add("محمـد نجيب");
        secondLine.add("العتبة");
        secondLine.add("الشهداء");
        secondLine.add("مسرة");
        secondLine.add("روض الفرج");
        secondLine.add("سانتا تريز");
        secondLine.add("الخلفاوى");
        secondLine.add("المظلات");
        secondLine.add("كلية الزراعة");
        secondLine.add("شبرا الخيمة");
        return secondLine ;
    }

    public ArrayList<String> initThirdLine()
    {
        ArrayList<String> thirdline = new ArrayList<>() ;

        thirdline.add("الأهرام") ;
        thirdline.add("كلية البنات") ;
        thirdline.add("ستاد القاهرة") ;
        thirdline.add("أرض المعارض") ;
        thirdline.add("العباسية") ;
        thirdline.add("عبده باشا") ;
        thirdline.add("الجيش") ;
        thirdline.add("باب الشعرية") ;
        thirdline.add("العتبة") ;

        return thirdline ;
    }

    public ArrayList<Station> makeStation( ArrayList<String> arr , int lineNumber )
    {
        ArrayList<Station> ans = new ArrayList<>() ;
        for(int i = 0 ; i < arr.size() ; i++ )
            ans.add( new Station( arr.get(i) , i , 0 , lineNumber ) ) ;

        return ans ;
    }


    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.go)
        {
            String fromText = from.getText().toString() ;
            String toText   = to.getText().toString() ;

            Intent i = new Intent(this , TripActivity.class ) ;
            if( (fromText != null && toText != null) ||  fromText.equals(" ") && toText.equals(" ") )
            {
                i.putExtra("from" , fromText) ;
                i.putExtra("to" , toText) ;
                startActivity(i);
            }
            else
                Toast.makeText(this , "Please Enter Correct values" , Toast.LENGTH_LONG).show() ;
        }
        else if (view.getId() == R.id.lines)
        {
            Intent i = new Intent(this , LinesListActivity.class ) ;
            startActivity(i);
        }
    }
}
