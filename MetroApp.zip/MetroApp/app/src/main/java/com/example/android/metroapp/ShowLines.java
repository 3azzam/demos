package com.example.android.metroapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.android.metroapp.DataBase.DbModel;

import java.util.ArrayList;

public class ShowLines extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_lines);

        Bundle bundle = getIntent().getExtras();
        int temp = bundle.getInt("line") ;


        DbModel dbModel = new DbModel(this) ;
        ArrayList<Station> arr = new ArrayList<>() ;

        if(temp == 1)
            arr = dbModel.getFirstLine() ;
        else if(temp == 2)
            arr = dbModel.getSecondLine() ;
        else
            arr = dbModel.getThirdLine() ;

        ArrayList<String> list = new ArrayList<>();
        for(int i = 0 ; i < arr.size() ; i++)
            list.add(arr.get(i).getName()) ;

        ArrayAdapter arrayAdapter = new ArrayAdapter(this ,android.R.layout.simple_list_item_1,list) ;
        ListView listView = (ListView) findViewById(R.id.showlines);
        listView.setAdapter(arrayAdapter);

    }
}
