package com.example.android.metroapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.metroapp.DataBase.DbModel;

import java.util.ArrayList;

public class TripActivity extends AppCompatActivity {

    private TextView price ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip);

        Bundle bundle = getIntent().getExtras() ;
        String from = bundle.getString("from") ;
        String to = bundle.getString("to") ;


        DbModel dbModel = new DbModel(this) ;

        RoadTripCalc roadTripCalc = new RoadTripCalc(dbModel) ;
        ArrayList<Station> arr = roadTripCalc.start( from , to ) ;

        ArrayList<String> stationNames = new ArrayList<>() ;
        for(int i = 0 ; i < arr.size() ; i++)
            stationNames.add(arr.get(i).getName()) ;

        int x = arr.size() ;
        if(x < 9) x = 3 ;
        else if(x < 16) x = 5 ;
        else x = 7 ;

        price = (TextView) findViewById(R.id.trip_price) ;
        price.setText("Ticket Price = " + x + " L.E ");

        ArrayAdapter arrayAdapter = new ArrayAdapter(this ,android.R.layout.simple_list_item_1 , stationNames ) ;
        ListView listView = (ListView) findViewById(R.id.list) ;
        listView.setAdapter(arrayAdapter);

        //Toast.makeText(this , "Ticket price = " + x , Toast.LENGTH_LONG).show();
    }
}
